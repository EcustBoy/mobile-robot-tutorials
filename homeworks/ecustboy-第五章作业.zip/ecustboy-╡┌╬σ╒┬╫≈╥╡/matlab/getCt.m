function Ct = getCt(n_seg, n_order)
    %#####################################################
    % STEP 2.1: finish the expression of Ct
    Ct=zeros((n_order+1)*n_seg,(n_order+1)/2*(n_seg+1));
    for i=1:n_seg
        %ÿһ�ζ�Ӧ����ʼ��
        if i==1
            Ct(1:(n_order+1)/2,1:(n_order+1)/2)=diag(ones(1,(n_order+1)/2));
        else
            for j=(n_order+1)*(i-1)+1:(n_order+1)*(i-1)+(n_order+1)/2 %C���������
                index=j-(n_order+1)*(i-1)-1;
                if index==0
                    Ct(j,(n_order+1)/2+i-1)=1;
                else
                    Ct(j,n_seg+n_order+((n_order+1)/2-1)*(i-2)+index)=1;
                end
            end
        end
        %ÿһ�ζ�Ӧ�ĺ�һ��
        if i==n_seg
            Ct((n_order+1)*(i-1)+(n_order+1)/2+1:(n_order+1)*i,(n_order+1)/2+n_seg:n_order+n_seg)=eye((n_order+1)/2);
        else
            for j=(n_order+1)*(i-1)+(n_order+1)/2+1:(n_order+1)*i %C���������
                index=j-((n_order+1)*(i-1)+(n_order+1)/2)-1;
                if index==0
                    Ct(j,(n_order+1)/2+i)=1;
                else
                    Ct(j,n_seg+n_order+((n_order+1)/2-1)*(i-1)+index)=1;
                end
            end
        end
        
            
    
    end
end