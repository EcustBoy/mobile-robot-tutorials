function M = getM(n_seg, n_order, ts)
    M = [];
    for k = 1:n_seg
        M_k = zeros(n_order+1,n_order+1);
        %#####################################################
        % STEP 1.1: calculate M_k of the k-th segment 
        for i=1:(n_order+1)/2
             M_k(i,i)=factorial(i-1);
        end
        for i=(n_order+1)/2+1:n_order+1
            flag=i-((n_order+1)/2+1);%�󵼴���
            for j=1:n_order+1
                if j<flag+1
                    M_k(i,j)=0;
                else
                    M_k(i,j)=factorial(j-1)/factorial(j-1-flag)*ts(k).^(j-1-flag);
                end
            end
            
        end
        M = blkdiag(M, M_k);
    end
end